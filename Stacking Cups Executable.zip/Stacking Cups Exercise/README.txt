Stacking Cups Exercise

To run the program, run StackingCups.exe

To interact with the program, use the buttons at the bottom,
or use the following keys on the keyboard:

UP ARROW - pick up cup
DOWN ARROW - drop cup (only yellow cups can be dropped)
RIGHT ARROW - move cup right
LEFT ARROW - move cup left
SPACE BAR - reset board