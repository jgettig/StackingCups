import cx_Freeze

executables = [cx_Freeze.Executable("StackingCups.py")]

cx_Freeze.setup(
    name="CupsTest",
    options={"build_exe": {"packages":["pygame", "sys"],
                           "include_files":["FieldControl.py"]}},
    executables = executables

    )