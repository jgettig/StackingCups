import sys
import pygame as g
from FieldControl import Game
g.init()

width = int(g.display.Info().current_w *.35)
height = int(width * (20/16))
size = width, height

black = 26,26,26

screen = g.display.set_mode(size, g.RESIZABLE)
g.display.set_caption('Stacking Cups')

gameControl = Game(screen)

keyIsPressed = False
mouseIsPressed = False
mousePressed = False

while 1:
    for event in g.event.get():
        if event.type == g.QUIT: sys.exit()
        elif event.type == g.KEYDOWN and not keyIsPressed:
            keyIsPressed = True
            gameControl.processEvent(event.key)
        elif event.type == g.KEYUP and keyIsPressed:
            keyIsPressed = False
            
    if g.mouse.get_pressed()[0] and not mouseIsPressed:
        mousePressed = True
        mouseIsPressed = True
    elif not g.mouse.get_pressed()[0] and mouseIsPressed:
        mouseIsPressed = False
    
    gameControl.processMouse(screen, mousePressed)
    mousePressed = False
    
    curDims = g.display.Info().current_w, g.display.Info().current_h
    if curDims != size:
        gameControl.resize(curDims)
        size = curDims

    screen.fill(black)
    gameControl.draw(screen)
    g.display.flip()