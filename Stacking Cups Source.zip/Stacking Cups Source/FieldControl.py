import sys
import pygame as g
import pygame.gfxdraw

black = 26, 26, 26
BLACK = 0,0,0
white = 255, 255, 255
blue = 0, 102, 204
yellow = 204, 204, 0
red = 204, 0, 0

#class that encompasses whole game
#uses GUI and Field for abstraction
class Game:
    
    def __init__(self, screen: g.Surface):
        w = screen.get_width()
        h = screen.get_height()
        
        #save all params for spacing
        self.cupWidth = int(w/8)
        self.cupHeight = int(3 * h / 20)
        self.buttonWidth = int(self.cupWidth / 5) * 5
        self.buttonHeight = int(h/10 / 5) * 5
        self.cupBuffer = int(w / 24)
        self.buttonBuffer = int((w - (5 * self.buttonWidth)) / 6)
        self.hBuffer = int(h / 20)
        
        #initialize GUI elements
        self.gui = GUI(self.buttonHeight, self.buttonWidth, self.buttonBuffer)
        
        #initialize cup field elements
        self.field = Field(self.cupHeight, self.cupWidth, self.cupBuffer, self.hBuffer)
    
    #in case user resizes window
    def resize(self, dims):
        w = dims[0]
        h = dims[1]
        
        #recalculate spacing params with new dimensions
        self.cupWidth = int(w/8)
        self.cupHeight = int(3 * h / 20)
        self.buttonWidth = int(self.cupWidth / 5) * 5
        self.buttonHeight = int(h/10 / 5) * 5
        self.cupBuffer = int(w / 12)
        self.buttonBuffer = int((w - (5 * self.buttonWidth)) / 6)
        self.hBuffer = int(h / 20)
        
        #tell gui to resize
        self.gui.resize(self.buttonHeight, self.buttonWidth, self.buttonBuffer)
        self.field.resize(self.cupHeight, self.cupWidth, self.cupBuffer, self.hBuffer)
    
    #tell Field and GUI to draw elements
    def draw(self, screen: g.Surface):
        
        #have field draw
        self.field.draw(screen)
        
        #have gui draw
        self.gui.draw(screen, 2 * self.hBuffer + 5 * self.cupHeight)
        
    def processEvent(self, key):
        if key == -1:
            return
        if key == g.K_UP:
            self.field.pick()
        if key == g.K_SPACE:
            self.field.reset()
        if key == g.K_RIGHT:
            self.field.moveRight()
        if key == g.K_DOWN:
            self.field.drop()
        if key == g.K_LEFT:
            self.field.moveLeft()     
    
    def processMouse(self, screen, pressed):
        self.processEvent(self.gui.processMouse(screen, pressed, 2 * self.hBuffer + 5 * self.cupHeight))
            
#controller for all cup actions    
class Field:
    
    def __init__(self, h, w, wBuf, hBuf):
        #create grid where cups will live
        #grid values are 
        #0 when there is no cup
        #1 when there is a placed cup
        #2 when there is a held cup
        self._grid_init()
        
        #save cup width, height, and buffer width and height
        self.cWidth = w
        self.cHeight = h
        self.wBuffer = wBuf
        self.hBuffer = hBuf
        
        #tracks whether there is a picked cup not on the grid
        self.basePicked = False
        self.cupGrabbed = False
        
        self.curPos = [0, -1]
        self.atValidPos = True
    
    #save new positional values
    def resize(self, h, w, wBuf, hBuf):
        self.cWidth = w
        self.cHeight = h
        self.wBuffer = wBuf
        self.hBuffer = hBuf        
        
    #iterate through and make grid of cups in 5/4 pattern with 5 rows
    def _grid_init(self):
        self.grid = []
        
        for i in range(0,5):
            self.grid.append([])
            for j in range(0,10):
                self.grid[i].append(0)
    
    
    #display all cups
    def draw(self, screen: g.Surface):
        
        #start by drawing permanent cup pile
        self._drawCup(screen, (self.wBuffer, self.hBuffer + 4 * self.cHeight), blue)
        
        lSpace = 2*self.wBuffer + self.cWidth
        for i in range(0, 5):
            hPos = self.hBuffer + (4-i) * self.cHeight
            for j in range(0, 10):
                if self.grid[i][j] == 1:
                    self._drawCup(screen, (lSpace + j/2 * self.cWidth, hPos), blue)
                elif self.grid[i][j] == 2:
                    if self.atValidPos:
                        self._drawCup(screen, (lSpace + j/2 * self.cWidth, hPos - .5 * self.hBuffer), yellow)
                    else:
                        self._drawCup(screen, (lSpace + j/2 * self.cWidth, hPos - .5 * self.hBuffer), red)
                   
        
        if self.basePicked:
            self._drawCup(screen, (self.wBuffer, 4 * self.cHeight), yellow)
    
    #helper to simplify drawing cups
    def _drawCup(self, screen, loc, color):
        points = (
            (loc[0], loc[1] + self.cHeight),
            (loc[0] + self.cWidth / 5, loc[1]),
            (loc[0] + 4 * self.cWidth / 5, loc[1]),
            (loc[0] + self.cWidth, loc[1] + self.cHeight))
        
        g.gfxdraw.filled_polygon(screen, points, color)
        g.gfxdraw.aapolygon(screen, points, BLACK)
        
    #'pick up a cup'
    def pick(self):
        if not self.cupGrabbed:
            self.cupGrabbed = True
            self.basePicked = True
            
    #reset all values to default  
    def reset(self):
        self._grid_init()
        self.cupGrabbed = False
        self.basePicked = False        
        self.curPos = [0, -1]
    
    def moveRight(self):
        if self.cupGrabbed:
            if self.curPos[1] == -1:
                idxTo = -1
                for i in range(0, 5):
                    if not (self.grid[i][0] == 1 or self.grid[i][1] == 1):
                        idxTo = i;
                        break
                        
                if idxTo == -1:
                    return
                
                self.curPos = [idxTo, 0]
                self.basePicked = False
            elif self.curPos[1] == 9:
                return
            elif self.curPos[1] == 8:
                self._setGridAtPos(self.curPos, 0)
                self.curPos[1] = 9
                for i in range(0, 5):
                    if not (self.grid[i][8] == 1 or self.grid[i][9] == 1):
                        self.curPos[0] = i
                        break
            else:
                nextPos = self.curPos[1] + 1
                posTo = [self.curPos[0], self.curPos[1]]
                for i in range(0, 5):
                    if not (self.grid[i][nextPos - 1] == 1 or self.grid[i][nextPos] == 1 or self.grid[i][nextPos + 1] == 1):
                        posTo[0] = i
                        posTo[1] = nextPos
                        break                          
                self._setGridAtPos(self.curPos, 0)
                self.curPos = [posTo[0], posTo[1]]
            
            self._setGridAtPos(self.curPos, 2)
            self.atValidPos = self._atValidSpot()
    
    def moveLeft(self):
        if self.cupGrabbed and self.curPos[1] >= 1:
            if self.curPos[1] == 1:
                self._setGridAtPos(self.curPos, 0)
                self.curPos[1] = 0
                for i in range(0, 5):
                    if not (self.grid[i][0] == 1 or self.grid[i][1] == 1):
                        self.curPos[0] = i
                        break
            else:
                nextPos = self.curPos[1] - 1
                posTo = [self.curPos[0], self.curPos[1]]
                for i in range(0, 5):
                    if not (self.grid[i][nextPos - 1] == 1 or self.grid[i][nextPos] == 1 or self.grid[i][nextPos + 1] == 1):
                        posTo[0] = i;
                        posTo[1] = nextPos
                        break          
                    
                self._setGridAtPos(self.curPos, 0)
                self.curPos = [posTo[0], posTo[1]]            
            
            self._setGridAtPos(self.curPos, 2)
            self.atValidPos = self._atValidSpot()            
    
    def drop(self):
        if self.cupGrabbed and not self.basePicked:
            if self.atValidPos:
                self._setGridAtPos(self.curPos, 1)
                self.cupGrabbed = False
                self.curPos = [0, -1]
    
    def _atValidSpot(self):
        if self.curPos[1] == 0 or self.curPos[1] == 9:
            return self.curPos[0] == 0
        return self.curPos[0] == 0 or (self.grid[self.curPos[0]-1][self.curPos[1]-1] == 1 and self.grid[self.curPos[0]-1][self.curPos[1]+1] == 1)
    
    
    def _setGridAtPos(self, pos, val):
        self.grid[pos[0]][pos[1]] = val
        
    
class GUI:
    
    def __init__(self, h, w, buffer):
        #save button width and height, plus buffer
        self.bWidth = w
        self.bHeight = h
        self.buffer = buffer
        
        #initialize arrow points (helps readability)
        self._initPoints(w, h)
        
        buttonTemplate = g.Surface((w, h))
        buttonTemplate.fill(black)
        self._initArrows(buttonTemplate)
    
        self.hover = [False] * 5
        
        self.hoverSurf = g.Surface((self.bWidth, self.bHeight), g.SRCALPHA)
        self.hoverSurf.fill((255,255,255,20))
    
    #function to update values when window resized
    def resize(self, h, w, buffer):
        self.bWidth = w
        self.bHeight = h
        self.buffer = buffer        
        
        self._initPoints(w, h)
        
        buttonTemplate = g.Surface((w, h))
        buttonTemplate.fill(black)
        self._initArrows(buttonTemplate)        
        
        self.hoverSurf = g.Surface((self.bWidth, self.bHeight), g.SRCALPHA)
        self.hoverSurf.fill((255,255,255,20))        
    
    
    #create arrow templates
    def _initPoints(self, w, h):
        upPoints = (
            (w/2, 0),
            (w/5, h/3),
            (2*w/5, h/3),
            (2*w/5, h),
            (3*w/5, h),
            (3*w/5, h/3),
            (4*w/5, h/3))     
        
        downPoints = (
            (2*w/5, 0),
            (2*w/5, 2*h/3),
            (w/5, 2*h/3),
            (w/2, h),
            (4*w/5, 2*h/3),
            (3*w/5, 2*h/3),
            (3*w/5, 0))
        
        leftPoints = (
            (0, 2*h/5),
            (0, 3*h/5),
            (2*w/3, 3*h/5),
            (2*w/3, 4*h/5),
            (w, h/2),
            (2*w/3, h/5),
            (2*w/3, 2*h/5))
        
        rightPoints = (
            (w, 2*h/5),
            (w/3, 2*h/5),
            (w/3, h/5),
            (0, h/2),
            (w/3, 4*h/5),
            (w/3, 3*h/5),
            (w, 3*h/5))
        
        self.points = [upPoints, downPoints, rightPoints, leftPoints]
        
    
    #turn points from _initPoints into Surface objects
    def _initArrows(self, surf):

        h = surf.get_height()
        w = surf.get_width()
        
        self.arrows = []
        
        for i in range(0, len(self.points)):
            self.arrows.append(surf.copy())
            g.gfxdraw.aapolygon(self.arrows[i], self.points[i], blue)       
            g.gfxdraw.filled_polygon(self.arrows[i], self.points[i], blue)     
                  
    
    
    
    #draw arrows plus reset button
    def draw(self, screen: g.Surface, hLoc):
        
        #for readability
        h = self.bHeight
        w = self.bWidth  
        
        #draw all 4 arrows
        for i in range(0, len(self.arrows)):
            screen.blit(self.arrows[i], (self.buffer * (i + 1) + w * i, hLoc))
            if self.hover[i]:
                screen.blit(self.hoverSurf, (self.buffer * (i + 1) + w * i, hLoc))            
        
        
        #save radii and center positions for circular arrow
        iRad = int(w * 2/10) if w <= h else int(h * 2/10)
        oRad = iRad*2
        cPos = (int(self.buffer * 5 + w * 4 + w/2), int(hLoc + h/2))
        
        #points for arrow head
        resetPoints = (
            (int(w/2 + iRad/2), h/2),
            (int(w/2 + 5*iRad/2), h/2),
            (int(w/2 + iRad*1.5), 7*h/10))
        
        #points to break arrow circle
        clearPoints = (
            (w/2, h/2),
            (w, h/2),
            (w, h),
            (7*w/10, h))        
        
        #create arrow head Surface
        resetArrow = g.Surface((w, h))
        resetArrow.fill((0,0,0))
        resetArrow.set_colorkey((0,0,0))
        g.gfxdraw.aapolygon(resetArrow, resetPoints, blue)
        g.gfxdraw.filled_polygon(resetArrow, resetPoints, blue)
        
        #create surface to clear arrow circle
        resetClear = g.Surface((w, h))
        resetClear.fill((0,0,0))
        resetClear.set_colorkey((0,0,0))
        g.gfxdraw.filled_polygon(resetClear, clearPoints, black)      
        
        #create outer circle
        g.gfxdraw.aacircle(screen, cPos[0], cPos[1], oRad, blue)
        g.gfxdraw.filled_circle(screen, cPos[0], cPos[1], oRad, blue)
        
        #create inner circle
        g.gfxdraw.aacircle(screen, cPos[0], cPos[1], iRad, black)
        g.gfxdraw.filled_circle(screen, cPos[0], cPos[1], iRad, black)
        
        #blit both surfaces, finishing reset arrow
        screen.blit(resetClear, (self.buffer * (5) + w * 4, hLoc))
        screen.blit(resetArrow, (self.buffer * (5) + w * 4, hLoc))

        if self.hover[4]:
            screen.blit(self.hoverSurf, (self.buffer * (5) + w * 4, hLoc))        
        
        
    def processMouse(self, screen, pressed, hLoc):
        h = self.bHeight
        w = self.bWidth
        
        pos = g.mouse.get_pos()
        
        ret = -1
        
        for i in range(0, len(self.hover)):
            if (pos[0] >= (self.buffer * (i + 1) + w * i) and pos[0] <= (self.buffer * (i + 1) + w * (i+1)) and
                pos[1] >= hLoc and pos[1] <= (hLoc + h)):
                
                self.hover[i] = True
                if pressed:
                    ret = i
                break
            else:
                self.hover[i] = False
        
        if pressed:
            if ret == 0:
                ret = g.K_UP
            elif ret == 1:
                ret = g.K_DOWN
            elif ret == 2:
                ret = g.K_LEFT
            elif ret == 3:
                ret = g.K_RIGHT
            elif ret == 4:
                ret = g.K_SPACE
        
        if g.mouse.get_pressed()[0]:
            self.hover = [False] * 5
            
        
        return ret
            
                            